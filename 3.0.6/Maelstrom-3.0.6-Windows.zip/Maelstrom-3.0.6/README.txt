
                          Maelstrom 3.0

Maelstrom 3.0 is a GPL'd port of the original shareware game for the
Macintosh.  It is a fast-action, high resolution (640x480) asteroids-like
game, with detailed graphics and original sounds.

The GPL version of Maelstrom is not supported by Ambrosia Software,
but is recommended highly! :)

The latest GPL'd version of Maelstrom is available at:
	http://www.devolution.com/~slouken/Maelstrom/

The original Macintosh version of this game is available at:
	http://www.ambrosiasw.com/

Check out the file "INSTALL" in the source distribution for instructions
on building and installing Maelstrom from source code.

Check out the file "README.network" for information on how to play
networked Maelstrom.

See the file "README.options" for more information on the command line
options and compile-time features.

The Docs directory contains FAQs, press-releases, and technical notes
about the Maelstrom porting process.

Enjoy!
	-Sam Lantinga			(slouken@devolution.com)

